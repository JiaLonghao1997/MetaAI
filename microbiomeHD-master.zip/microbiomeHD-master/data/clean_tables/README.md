This file will contain the cleaned up OTU tables and metadata in feather
format. The files here are made from `src/data/clean_otu_and_metadata.py`.
