This folder will contain some of the intermediate files used in preparing
the phyloT tree.

The file included, *phyloT_tree.updated.newick* is the tree that was used in
the paper.
