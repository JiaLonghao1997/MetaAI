This folder contains the scripts I used to do various analyses. The results from these scripts end up mostly in `../../data/analysis_results/`
