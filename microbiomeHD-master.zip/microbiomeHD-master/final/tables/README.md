This folder will contain the tables made by `make tables`, via scripts in `../../src/final/`.

When made, each table will be presented in Latex (for the manuscript), Markdown (for humans/github), 
and tab-delimited (for humans/computers) formats.

For now, the repo just comes with the Markdown versions.