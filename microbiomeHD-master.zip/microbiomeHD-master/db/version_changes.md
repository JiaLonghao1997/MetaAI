**Version changes**

Version 3

* added missing ob_escobar metadata   
* added ob_jumpertz, ob_zeevi, and ob_wu   
* added README.txt files to all folders, with info about data downloading and processing steps   
* removed deprecated quality_control folders from all dataset results    
* changed Supplemental File S3 to the most updated version of non-specific genera (as published in Duvallet et al 2017)   

Version 2

* added crc_zhu and ob_escobar datasets   
* added list of core genera and dataset_info.yaml   
